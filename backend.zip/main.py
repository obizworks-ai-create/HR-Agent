from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from dotenv import load_dotenv
import os
from routers.api import router as api_router
from routers.dashboard import router as dashboard_router
from routers.interview import router as interview_router

load_dotenv()

app = FastAPI(title="HR Hiring Pipeline API")

origins = [
    "http://localhost:5173",  # React default port
    "http://localhost:3000",
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(api_router, prefix="/api")
app.include_router(dashboard_router, prefix="/api", tags=["dashboard"])
app.include_router(interview_router, prefix="/api/interview", tags=["interview"])

@app.get("/")
def read_root():
    return {"message": "HR Pipeline API is running"}
